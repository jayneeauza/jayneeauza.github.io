$(document).ready(function() {
	$("#btnhome").click(function() {
		window.location.href="home.php";
	});

	$("#idadown").click(function() {
		window.location.href="home.php";
	});
});